//
//  SCI_RecoveryApp.swift
//  SCI Recovery
//
//  Created by Tolga Saygi on 10/25/21.
//

import SwiftUI

@main
struct SCI_RecoveryApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
