def get_inclusion_x_cols():
	return [
		'AInjDt',
		'AInjAge',
		'ASex',
		'AHghtRhb',
		'AWghtRhb',
		'ANurLvlA',
		'AAnSnAdm', # 2903 entries
		'AVoSphAd', # 2903 entries
		'AASAImAd',
		'ANCatAdm',
		'ARace',
		'AMarStIj',
		'AEducLvl',
		'APrLvlSt',
		'AJobCnCd',
		'AFmIncLv',
		'AVeteran',
		'APrimPay',
		'ADepress',
		'AAnxiety',
		'ADiabete',
		'AAlcNbDr',
		'ATBILOC',
		'ATBIMem',
		'ATBISevR'
	]

def get_inclusion_y_cols():
	return [
		'ANurLvlD',
		'ANCatDis',
		'AASAImDs'
	]
