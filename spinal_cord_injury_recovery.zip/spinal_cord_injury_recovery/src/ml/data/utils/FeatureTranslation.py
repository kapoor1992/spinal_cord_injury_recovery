class FeatureTranslation:
    def __init__(self, name, mappings):
        self.name = name
        self.mappings = mappings